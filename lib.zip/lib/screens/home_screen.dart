import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'profile_screen.dart';
import 'dart:convert';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

String cleanBase64(String base64String) {
  if (base64String.startsWith('data:image')) {
    final parts = base64String.split(',');
    return parts.length > 1 ? parts[1] : '';
  }
  return base64String;
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  String deliveryAddress = 'Chargement...';
  String searchQueryByName = ''; // To store the search query for name
  String searchQueryByCategory = ''; // To store the search query for category

  final List<Widget> _screens = [
    const HomeContentScreen(),
    const Center(child: Text("Favoris")),
    const Center(child: Text("Panier")),
    const ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _fetchAddress();
  }

  Future<void> _fetchAddress() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        setState(() => deliveryAddress = 'Utilisateur non connecté');
        return;
      }

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(currentUser.uid)
          .get();

      setState(() {
        deliveryAddress = userDoc.exists
            ? (userDoc['address'] ?? 'Adresse non disponible')
            : 'Adresse introuvable';
      });
    } catch (e) {
      setState(() => deliveryAddress = 'Erreur de chargement de l\'adresse');
      debugPrint('Erreur lors de la récupération de l\'adresse : $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
            if (_currentIndex == 0) _fetchAddress(); // Refresh address on home tab
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Accueil'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite_border), label: 'Favoris'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_cart), label: 'Panier'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
      ),
    );
  }
}

class HomeContentScreen extends StatelessWidget {
  const HomeContentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final homeScreenState = context.findAncestorStateOfType<_HomeScreenState>();
    final deliveryAddress = homeScreenState?.deliveryAddress ?? 'Chargement...';
    final searchQueryByName = homeScreenState?.searchQueryByName ?? '';
    final searchQueryByCategory = homeScreenState?.searchQueryByCategory ?? '';

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            const Icon(Icons.location_on, color: Colors.blue),
            const SizedBox(width: 5),
            Expanded(
              child: Text(
                'Livraison : $deliveryAddress',
                style: const TextStyle(color: Colors.black, fontSize: 14),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: Colors.black),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSearchBar(homeScreenState),
            const SizedBox(height: 15),
            _buildHighlightProduct(),
            const SizedBox(height: 15),
            _buildPopularCategories(),
            const SizedBox(height: 15),
            _buildProductGrid(searchQueryByName, searchQueryByCategory),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchBar(_HomeScreenState? homeScreenState) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Search by name
        TextField(
          onChanged: (query) {
            if (homeScreenState != null) {
              homeScreenState.setState(() {
                homeScreenState.searchQueryByName = query;
              });
            }
          },
          decoration: InputDecoration(
            labelText: 'Rechercher par nom...',
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
            ),
          ),
        ),
        const SizedBox(height: 10),
        // Search by category
        TextField(
          onChanged: (query) {
            if (homeScreenState != null) {
              homeScreenState.setState(() {
                homeScreenState.searchQueryByCategory = query;
              });
            }
          },
          decoration: InputDecoration(
            labelText: 'Rechercher par catégorie...',
            prefixIcon: const Icon(Icons.search),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProductGrid(String searchQueryByName, String searchQueryByCategory) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('products').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return const Center(child: Text('Erreur lors du chargement des produits'));
        }
        final products = snapshot.data?.docs ?? [];
        final filteredProducts = products.where((product) {
          final name = product['name'] ?? '';
          final category = product['category'] ?? '';
          return (name.toLowerCase().contains(searchQueryByName.toLowerCase()) ||
              category.toLowerCase().contains(searchQueryByCategory.toLowerCase()));
        }).toList();

        return filteredProducts.isEmpty
            ? const Center(child: Text('Aucun produit trouvé'))
            : GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filteredProducts.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemBuilder: (context, index) {
                  final product = filteredProducts[index];
                  return _buildProductCard(
                    product['name'] ?? 'Produit sans nom',
                    product['image'] ?? '',
                    product['price']?.toString() ?? '0.00',
                  );
                },
              );
      },
    );
  }

  Widget _buildProductCard(String name, String image, String price) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      child: Column(
        children: [
          Expanded(
            child: image.isNotEmpty
                ? (image.startsWith('data:image')
                    ? Image.memory(
                        base64Decode(cleanBase64(image)),
                        width: double.infinity,
                        height: 100,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.image_not_supported, size: 50);
                        },
                      )
                    : Image.network(
                        image,
                        width: double.infinity,
                        height: 100,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(Icons.image_not_supported, size: 50);
                        },
                      ))
                : const Icon(Icons.image_not_supported, size: 50),
          ),
          Padding(
            padding: const EdgeInsets.all(6),
            child: Text(
              name,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(6),
            child: Text(
              '$price DT',
              style: const TextStyle(fontSize: 10, color: Colors.grey),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHighlightProduct() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.pink.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Image.asset('lib/assets/rose_hibiscus_mist.png', width: 50, height: 80),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('Rose Hibiscus Mist', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              Text('\36.00 DT', style: TextStyle(fontSize: 10, color: Colors.grey, decoration: TextDecoration.lineThrough)),
              Text('Promo: \26.00 DT', style: TextStyle(fontSize: 12, color: Colors.pink)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPopularCategories() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Image.asset('lib/assets/butterfly_white_slim.png', width: 50, height: 80),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('Cosmetics', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              Text('All products here', style: TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ),
        ],
      ),
    );
  }
}
